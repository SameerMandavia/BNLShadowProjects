import { Injectable } from '@angular/core';
import { User } from 'src/app/Models/user';
import { Observable, throwError } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Login } from 'src/app/Models/login';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class LoginService {
  constructor(private http: HttpClient) {}

  private LOGIN_URI: string = 'http://localhost:9090/cafe/login';

  userLogin(userLogin: Login): Observable<User> {
    console.log(userLogin.userName);
    console.log(userLogin.password);

    return this.http
      .post<User>(this.LOGIN_URI, userLogin)
      .pipe(catchError(this.handleError));
  }

  private handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // client-side error
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // server-side error
      errorMessage = `${error.error.message}`;
    }
    alert(errorMessage);
    return throwError(errorMessage);
  }
}
