
/**
 * User DTO class.
 * @author sameer mandavia
 * 
 * */ 

export class User {

    userId : number;
    userName : string;
    emailId : string;
    password : string;

}
