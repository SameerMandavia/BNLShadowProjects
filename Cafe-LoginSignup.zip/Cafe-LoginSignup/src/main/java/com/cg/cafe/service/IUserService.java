package com.cg.cafe.service;

import com.cg.cafe.dto.Login;
import com.cg.cafe.dto.User;

public interface IUserService {

	public User signUp(User user);

	public User userLogin(Login login);

	public User getUserName(String userName);

}
