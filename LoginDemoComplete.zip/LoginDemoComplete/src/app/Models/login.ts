/**
 * Login DTO class.
 * @author sameer mandavia
 *
 * */

export class Login {
  public userName: string;
  public password: string;
}
